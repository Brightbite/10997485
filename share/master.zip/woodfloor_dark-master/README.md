# Woodfloor Dark
> A dark theme for Nagios 3.x.

Woodfloor Dark is theme for Nagios 3.x.  
Based on Eduardo L. Arana's [Arana Theme 1.0](http://sourceforge.net/projects/arana-nagios/) for Nagios 3.x

## Install
Backup and replace the Nagios 'htdocs' directory.
on Debian it's @ /usr/share/nagios3

## Screenshots

![Image](http://i.imgur.com/UjOgSHT.png)

![Image](http://i.imgur.com/ALSmJWY.png)

![Image](http://i.imgur.com/IpK6ljU.png)

![Image](http://i.imgur.com/07UTMaR.png)

![Image](http://i.imgur.com/ZO7zbyy.png)

[![GNU GPL v3.0](http://www.gnu.org/graphics/gplv3-127x51.png)](http://www.gnu.org/licenses/gpl.html)

View official GNU site <http://www.gnu.org/licenses/gpl.html>.